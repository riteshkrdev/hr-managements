export * from './admin.component';
