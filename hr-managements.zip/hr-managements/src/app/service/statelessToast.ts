import { tap } from 'rxjs/operators';
import { ToastService } from './toast.service';

export function withToast<T>(
  toast: ToastService,
  successMsg: string,
  errorMsg?: string
) {
  return tap<T>({
    next: () => toast.showSuccess(successMsg),
    error: (err) => toast.showError(errorMsg || 'Operation Failed')
  });
}