import { ApplicationConfig, provideBrowserGlobalErrorListeners } from '@angular/core';
import { provideRouter } from '@angular/router';
import { providePrimeNG } from 'primeng/config';
import Materials from '@primeuix/themes/material';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { toastInterceptor } from './interceptors/toast.interceptor';
import { MessageService, ConfirmationService } from 'primeng/api';

// project import
import { AdminComponent } from './demo/layout/admin';

export const appConfig: ApplicationConfig = {
  providers: [
    provideBrowserGlobalErrorListeners(),
    provideRouter([
      {
        path: '',
        component: AdminComponent,
        children: [
          {
            path: '',
            redirectTo: '/dashboard',
            pathMatch: 'full'
          },
          {
            path: 'dashboard',
            loadComponent: () => import('./demo/pages/dashboard/dashboard.component')
          },
          {
            path: 'employee',
            loadComponent: () => import('./employee-page/employee-page').then((m) => m.EmployeePage)
          }
        ]
      }
    ]),
    provideHttpClient(withInterceptors([toastInterceptor])),
    MessageService,
    ConfirmationService,
    providePrimeNG({
      theme: {
        preset: Materials
      }
    })
  ]
};
