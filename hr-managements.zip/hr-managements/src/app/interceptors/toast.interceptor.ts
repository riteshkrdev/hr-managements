import { inject } from '@angular/core';
import {
  HttpInterceptorFn,
  HttpResponse,
  HttpErrorResponse
} from '@angular/common/http';
import { tap } from 'rxjs/operators';
import { ToastService } from '../service/toast.service';

export const toastInterceptor: HttpInterceptorFn = (req, next) => {

  const notification = inject(ToastService);

  return next(req).pipe(
    tap({
      next: (event) => {

        if (event instanceof HttpResponse &&
          ['GET', 'POST', 'PUT', 'DELETE'].includes(req.method)) {

          switch (req.method) {
            case 'GET':
              notification.showSuccess('Data Loaded Successfully');
              break;
            case 'POST':
              notification.showSuccess('Created Successfully');
              break;
            case 'PUT':
              notification.showSuccess('Updated Successfully');
              break;
            case 'DELETE':
              notification.showError('Deleted Successfully');
              break;
          }
        }
      },
      error: (error: HttpErrorResponse) => {
        notification.showError(
          error.error?.message || error.message
        );
      }
    })
  );
};